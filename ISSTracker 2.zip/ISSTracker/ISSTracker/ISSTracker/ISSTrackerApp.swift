//
//  ISSTrackerApp.swift
//  ISSTracker
//
//  Created by Joe Fabre on 3/2/25.
//

import SwiftUI

@main
struct ISSTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
