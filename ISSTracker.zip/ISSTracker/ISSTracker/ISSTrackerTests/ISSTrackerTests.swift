//
//  ISSTrackerTests.swift
//  ISSTrackerTests
//
//  Created by Joe Fabre on 3/2/25.
//

import Testing

struct ISSTrackerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
